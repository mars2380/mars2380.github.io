ShareMouse Portable Edition - Installation
------------------------------------------

Please copy the "ShareMouse" directory included in 
this ZIP archive into any directory on your 
USB memory device.

Please note that not all ShareMouse features are 
available if running in portable mode 
(e.g. remote controlling UAC protected dialogs).

Additional information:
https://www.sharemouse.com/doc/installation/#portable


--


Bitte kopieren Sie zur Verwendung von ShareMouse
den Inhalt dieser Archivdatei in ein beliebiges 
Verzeichnis auf Ihrem USB Speicherstick.

Sie k�nnen das Programm von dort starten.

Bitte beachten Sie, das systembedingt einige Funktionen
beim Betrieb von einem USB Stick nicht unterst�tzt werden
k�nnen, weil diese einen Eingriff auf das Gastsystem 
erfordern w�rden (zum Beispiel das Fernsteuern von 
Rechnern im UAC gesch�tzten Modus).

Weitere Informationen:
https://www.sharemouse.com/de/doc/installation/


� Bartels Media GmbH